#include<bits/stdc++.h>
using namespace std;

int main()
{
   // automatic variable
   auto b = 10;
   
   return 0;
}
