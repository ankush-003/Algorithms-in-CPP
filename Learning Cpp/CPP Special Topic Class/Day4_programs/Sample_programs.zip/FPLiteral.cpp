#include <iostream>
using namespace std;

int main()
{
    // defining floating-point literal
    const float P= 128.88;
    cout<<"Floating-point literal: "<<P<<"\n";
    return 0;
}
