#include<bits/stdc++.h>
using namespace std;

class student 
{
  public:
    // instance variables
    int roll_no;
    string name;
    int marks;
};

int main() 
{
  // defining object of the class student
  student s;

  return 0;
}
